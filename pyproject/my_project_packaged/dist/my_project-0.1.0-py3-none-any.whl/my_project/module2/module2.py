def hello_world():
    print("Hello from Module 2!")