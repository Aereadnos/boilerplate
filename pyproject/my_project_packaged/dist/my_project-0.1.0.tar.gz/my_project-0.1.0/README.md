# My Project

This is a sample Python project with three modules, each in its own subdirectory, packaged with pyproject.toml.